const BASE_URL = "https://lldev.thespacedevs.com/2.3.0"

export { BASE_URL }